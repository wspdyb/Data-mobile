package com.wspdyb.datatoggle;

import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import java.io.DataOutputStream;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnEnable = findViewById(R.id.btnEnable);
        Button btnDisable = findViewById(R.id.btnDisable);

        btnEnable.setOnClickListener(v -> runRootCommand("svc data enable"));
        btnDisable.setOnClickListener(v -> runRootCommand("svc data disable"));
    }

    private void runRootCommand(String command) {
        try {
            Process su = Runtime.getRuntime().exec("su");
            DataOutputStream outputStream = new DataOutputStream(su.getOutputStream());
            outputStream.writeBytes(command + "\n");
            outputStream.writeBytes("exit\n");
            outputStream.flush();
            su.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
